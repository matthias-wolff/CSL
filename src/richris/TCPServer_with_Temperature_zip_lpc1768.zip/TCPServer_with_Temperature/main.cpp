
/*low level ethernet tcp server
with example temperature
by Christian Richter*/


#include "mbed.h"

//network
#include "EthernetInterface.h"
#include "rtos.h"
#include "NetworkAPI/tcp/socket.hpp"

#define ECHO_SERVER_PORT   55000
#define MAX_PENDING        1

//sensor
#include "LM75B.h"

//display
#include "C12832.h"

const char * HEARTBEAT = " "; // NOTE: Cannot be empty

//declare TCP/IP
const char * ip = "141.43.71.5";
const char * mask = "255.255.255.128";
const char * gateway = "141.43.71.126";

EthernetInterface eth;
TCPSocketConnection client;
TCPSocketServer server;

//declare LCD
C12832 lcd(p5, p7, p6, p8, p11);

//declare sensor
int sensorOk = 0;
LM75B sensor(p28,p27);
Serial pc(USBTX,USBRX);

void lcdPrint(char* message)
{
    if (!message) return;
    lcd.cls();
    lcd.locate(0,3);
    lcd.printf(message);
}

void replyRequest(char* reply, const char* request)
{
    // TODO: Application specify reply on requests by the client
    char s[255];        // LCD print buffer

    sprintf(s,"REQUEST: '%s'\n",request); lcdPrint(s);
    if (strcmp(request,"GET_TEMP")==0)
    {
        if (sensorOk)
            sprintf(reply,"TEMP=%.3f",(float)sensor);
        else
            sprintf(reply,"TEMP=SENSOR_ERROR");
    }
    else
    {
        // Just echo request
        strcpy(reply,request);
    }
    sprintf(s,"REQUEST: '%s'\nREPLY  : '%s'\n",request,reply); lcdPrint(s);
}

int main() 
{
    char request[256];  // TCP input buffer
    char reply[256];    // TCP output buffer
    char s[255];        // LCD print buffer
    
    // Open temperature sensor
    sensorOk = sensor.open();
    
    //activate ethernet TCP
    eth.init(ip, mask, gateway); 
    eth.connect();
    sprintf(s,"Server IP Address is %s\n",eth.getIPAddress()); lcdPrint(s);

    TCPSocketServer server;
    server.bind(ECHO_SERVER_PORT);
    server.listen(MAX_PENDING);

    while (true) 
    {
        sprintf(s,"LISTEN: %s\n",eth.getIPAddress()); lcdPrint(s);
        TCPSocketConnection client;
        server.accept(client);
        //client.set_blocking(false, 1500); // Timeout after (1.5)s
        
        sprintf(s,"ACCEPTED: %s\n",client.get_address()); lcdPrint(s);
        while (true) 
        {
            int n = client.receive(request, sizeof(request));
            if (n <= 0) break;
            
            // Remove tailing line break and add terminating '\0'
            if (n>0 && request[n-1]=='\n')
              n--;
            request[n] = '\0';
            
            if (strcmp(request,HEARTBEAT)==0)
            {
                // Heart beat -> just reply, do not print on LCD
                strcpy(reply,HEARTBEAT);
            }
            else
            {
                replyRequest(reply,request);
            }
            
            // Send reply to client
            n = strlen(reply);
            reply[n]='\n'; reply[n+1]='\0';
            client.send_all(reply,strlen(reply));
            if (n <= 0) break;
        }
        
        client.close();
    } 
}
