/**
 * Brandenburgische Technische Universität Cottbus
 * Lehrstuhl Kommunikationstechnik
 * SpeechLab
 *
 * Controller program for microphone array illumination.
 *
 * TCP/IP protocol:
 *
 * All LED-commands are complete strings separated by comma (",").
 * To set a specific LED you have to send an initial "LED",
 * followed by four values considering of LED-id and the
 * three RGB-values.
 *
 * - Set LED color          : ("LED,<LL>,<RR>,<GG>,<BB>")
 * - Set ambient light color: ("LED,0x20,<RR>,<GG>,<BB>")
 * - Reset                  : ("REST,0xC0,0xC0,0xC0,0xC0")
 * <LL>: LED number  (0x00..0x1F)
 * <RR>: Red value   (0x00..0xFF)
 * <GG>: Green value (0x00..0xFF)
 * <BB>: Blue value  (0x00..0xFF)
 *
 * @author Markus Marks, Robert Haertel, Matthias Wolff, Revision: Martin Birth
 */

#include "mbed.h"
#include "rtos.h"
#include "EthernetInterface.h"
#include <string.h>
#include <sstream>

#include "NetworkAPI/buffer.hpp"
#include "NetworkAPI/tcp/socket.hpp"
using namespace network;

#define I2CFREQ   500000     // I2C frequency in Hz
#define I2CR1       0xD0     // I2C address of board 1, red LED driver chip
#define I2CG1       0xD8     // I2C address of board 1, green LED driver chip
#define I2CB1       0xC0     // I2C address of board 1, blue LED driver chip
#define I2CR2       0xC2     // I2C address of board 2, red LED driver chip
#define I2CG2       0xC6     // I2C address of board 2, green LED driver chip
#define I2CB2       0xC8     // I2C address of board 2, blue LED driver chip

#define ECHO_SERVER_PORT   55000
#define MAX_PENDING        1

#define enum PREFIX {DONTUSE, LED, DEMO, RESET, ARRAY};

const char* MBED_NAME = "TV";   //  set CEIL or TV  !!IMPORTANT!!!

const char* LOCAL_IP_TV = "141.43.71.63";   // IP address of TV led array
const char* LOCAL_IP_CEIL = "141.43.71.64";     // IP address of CEIL led array
const char* NETWORK_MASK = "255.255.255.128";
const char* GATEWAY = "141.43.71.126";

const int SOCKET_BUFFER_SIZE = 726;
const int LED_STRLEN = 11;
const int ARR_STRLEN = 195;
const int MAX_TOKENS_PER_LINE = 64;
const char* const DELIMITER = ";";

I2C    i2c(p28,p27);         // The I2C bus
PwmOut ambientR(p21);        // The PWM output pin for the red ambient light
PwmOut ambientG(p22);        // The PWM output pin for the green ambient light
PwmOut ambientB(p23);        // The PWM output pin for the blue ambient light

uint8_t irqLed = 0;          // Interrupt routine: current LED
uint8_t irqCtr = 0;          // Interrupt routine: received byte counter
uint8_t ledData[33][4];      // RGB data buffer and modified-flags

Thread *demoThread;
bool demoModeOn = false;
const int DEMO_ROWS = 8;
const int CEIL_COLS = 5;
const int VIEW_COLS = 4;
int CEIL_DEMO[DEMO_ROWS][CEIL_COLS] = { 7, 13, 19, 25, 0, 8, 14, 20, 26, 25, 15,
        21, 27, 1, 0, 16, 22, 28, 2, 1, 23, 29, 3, 9, 0, 24, 30, 4, 10, 9, 31,
        5, 11, 17, 0, 32, 6, 12, 18, 17 };
int VIEWER_DEMO[DEMO_ROWS][VIEW_COLS] = { 5, 15, 6, 16, 4, 14, 7, 17, 3, 13, 8,
        18, 2, 12, 9, 19, 1, 11, 10, 20, 26, 32, 21, 27, 25, 31, 22, 28, 24, 30,
        23, 29 };

DigitalOut onBoardLeds[4]={LED1,LED2,LED3,LED4};
BusOut busLeds(LED1, LED2, LED3, LED4);
int numLeds = sizeof(onBoardLeds)/sizeof(DigitalOut);

/**
 * Small test program to check an incoming char
 * buffer from socket connection.
 */
void onBoardLedBlink(){
    while(1){
        int time = 50;
        for (int i = 0; i < numLeds; i++){
            busLeds = 1 << i;
            wait_ms(time);
        }
    }
}

/**
 * switch all on board leds to on
 */
void onBoardLedsOn(){
    for (int i = 0; i < numLeds; i++)
            onBoardLeds[i] = 1;
}

void onBoardLedsOff(){
    for (int i = 0; i < numLeds; i++)
            onBoardLeds[i] = 0;
}

/**
 * Writes two bytes to the I2C bus.
 *
 * @param addr
 *          The address.
 * @param v1
 *          The first byte.
 * @param v2
 *          The second byte.
 */
void i2cWrite(uint8_t addr, uint8_t v1, uint8_t v2){
    uint8_t i;
    char data[2] = { (char)v1, (char)v2 };

    for (i=0; i<10; i++) // Try writing max. 10 times
    if (i2c.write(addr,data,2)==0)
      break;
}

/**
 * Initializes one LED driver channel.
 *
 * @param addr
 *          The I2C address.
 */
void initLedDriver(uint8_t addr){
    i2cWrite(addr,0x00,0x00);
    i2cWrite(addr,0x14,0xAA);
    i2cWrite(addr,0x15,0xAA);
    i2cWrite(addr,0x16,0xAA);
    i2cWrite(addr,0x17,0xAA);
}

/**
 * Updates the color values of only ONE single LED.
 *
 * @param led
 *          The LED number (0x00...0x1F, 0x20 for the ambient light).
 */
void updateLed(uint8_t led){
  if (led>0x20) return;
  if (ledData[led][0]==0x00) return;

  ledData[led][0] = 0x00; // Clear modified-flag

  uint8_t r = ledData[led][1];
  uint8_t g = ledData[led][2];
  uint8_t b = ledData[led][3];

  if (led<=0x0F){
    led += 0x02;
    i2cWrite(I2CR1,led,r);
    i2cWrite(I2CG1,led,g);
    i2cWrite(I2CB1,led,b);
  }
  else if (led<=0x1F){
    led = led - 0x10 + 0x02;
    i2cWrite(I2CR2,led,r);
    i2cWrite(I2CG2,led,g);
    i2cWrite(I2CB2,led,b);
  }
  else{
    ambientR.write((float)r/255.);
    ambientG.write((float)g/255.);
    ambientB.write((float)b/255.);
  }
}

/**
 * Execute the update of the LED array
 */
void updateLedArray(){
    uint8_t led = 0;
    
    for(led=0x00; led<=0x20; led++)
        updateLed(led);
}

/**
 * (Re-)Initializes the LED driver chips and internal data.
 */
void resetLeds(){
    uint8_t i,j;

    // Initialize LED driver chips
    initLedDriver(I2CR1);
    initLedDriver(I2CG1);
    initLedDriver(I2CB1);
    initLedDriver(I2CR2);
    initLedDriver(I2CG2);
    initLedDriver(I2CB2);
    
    // Initialize RGB data buffer
    // - LEDs off, ambient light white
    // - Set all modified flags (j==0)
    for (i=0; i<=0x20; i++)
      for (j=0; j<=3; j++)
        ledData[i][j] = j==0?0x01:(i==0x20?0xFF:0x00);
      
    updateLedArray();
}

/**
 * Interpret an input char string as uint8_t value
 *
 * @param buf[]
 *      char array with the string
 * @return
 *      the first uint8_t value of the string
 */
unsigned int stringToUnsignedInt(string str){
    unsigned int value;
    std::stringstream sstream;
    sstream << std::hex << str;
    sstream >> value;
    return value;
}

/**
 * Set a single led value to the led array and update the stream
 */
void setAndUpdateLed(string buf){
    int len = buf.length();

    if (len != 11)
        return;
        
    uint8_t irqLed=stringToUnsignedInt(buf.substr(3,2));

    if (irqLed<0x21){
        ledData[irqLed][0]=0x01;  // Set modified-flag
        ledData[irqLed][1]=stringToUnsignedInt(buf.substr(5,2));     // set red value
        ledData[irqLed][2]=stringToUnsignedInt(buf.substr(7,2));     // set green value
        ledData[irqLed][3]=stringToUnsignedInt(buf.substr(9,2));     // set blue value
    }
    updateLedArray();
}

/**
 * Set all led values of the led array
 */
void setAndUpdateLedArray(string buf){
    int max = 0;
    int pos = 3;
    int len = buf.length();

    if (len == 195)
        max = 32;
    else if (len == 201)
        max = 33;
    else return;
    
    for(int i=0;i<max;i++,pos+=6){
        ledData[i][0]=0x01;
        ledData[i][1]=stringToUnsignedInt(buf.substr(pos,2));
        ledData[i][2]=stringToUnsignedInt(buf.substr(pos+2,2));
        ledData[i][3]=stringToUnsignedInt(buf.substr(pos+4,2));
    }
    
    updateLedArray();
}

void setLed(int irqLed, int r, int g, int b){
    if (irqLed < 0 || irqLed > 32)
        return;
    
    ledData[irqLed][0]=0x01;
    ledData[irqLed][1]=(uint8_t)r;
    ledData[irqLed][2]=(uint8_t)g;
    ledData[irqLed][3]=(uint8_t)b;
    updateLedArray();
}

void demoModeViewer(int r, int g, int b) {
    for (int i = 0; i < DEMO_ROWS; i++) {
        for (int j = 0; j < VIEW_COLS; j++) {
            setLed(VIEWER_DEMO[i][j] - 1, r, g, b);
        }
        Thread::wait(1000);

        for (int j = 0; j < VIEW_COLS; j++) {
            setLed(VIEWER_DEMO[i][j] - 1, 0, 0, 0);
        }
    }

    for (int i = DEMO_ROWS - 2; i > 0; i--) {
        for (int j = 0; j < VIEW_COLS; j++) {
            setLed(VIEWER_DEMO[i][j] - 1, r, g, b);
        }
        Thread::wait(1000);

        for (int j = 0; j < VIEW_COLS; j++) {
            setLed(VIEWER_DEMO[i][j] - 1, 0, 0, 0);
        }
    }
}

void demoModeCeil(int r, int g, int b) {
    for (int i = 0; i < DEMO_ROWS; i++) {
        for (int j=0; j < CEIL_COLS; j++) {
            setLed(CEIL_DEMO[i][j] - 1, r, g, b);
        }
        Thread::wait(1000);
    
        for (int j=0; j < CEIL_COLS; j++) {
            setLed(CEIL_DEMO[i][j] - 1, 0, 0, 0);
        }
    }
}

void runDemoMode(int r, int g, int b) {
    for(int i=0;i<32;i++)
        setLed(i, 0, 0, 0);
     
    setLed(32, r, g, b);

    demoModeOn = true;
    if(strcmp(MBED_NAME,"TV") == 0){
        while (demoModeOn) {
            demoModeViewer(r, g, b);
        }
    } else {  
        while (demoModeOn) {
            demoModeCeil(r, g, b);
        }
    }
    demoThread->terminate();
}

void startDemoMode(void const *args){
    runDemoMode(0, 0, 127);
  }
  
void stopDemoMode(){
    demoThread->terminate();
    demoModeOn=false; 
}  

// TODO: zusammengesetzte strings überprüfen: LED und ARR hintereinander!
void devideStringIntoSingleLedCommands(int setLen, char buf[]) {
    int len = strlen(buf);
    for (int i = 0; i < len; i += setLen) {
        if (len - i < setLen)
            return;

        if (setLen == LED_STRLEN)
            setAndUpdateLed(buf + i);
        else if (setLen == ARR_STRLEN)
            setAndUpdateLedArray(buf + i);
        else
            return;
    }
}

void singleStringParser(char buf[]) {
    char subbuf[4];
    memcpy( subbuf, &buf[0], 3 );
    subbuf[3] = '\0';
    
    if (strncmp(subbuf, "LED", 3) == 0) {
        devideStringIntoSingleLedCommands(LED_STRLEN,buf);
    } else if (strncmp(subbuf, "ARR", 3) == 0) {
        devideStringIntoSingleLedCommands(ARR_STRLEN,buf);
    } else if (strncmp(subbuf, "RES", 3) == 0) {
        stopDemoMode();
        resetLeds();
    } else if (strncmp(subbuf, "DEM", 3) == 0) {
        //if (demoThread->get_state() == Thread::Inactive) {
            delete demoThread;
            demoThread = new Thread(startDemoMode);
        //}
    } else { // every other string without LED, DEMO or RESET in the first token
        return;
    }
}

void devideStringInSingleCommands(char buf[]) {
    char* token[MAX_TOKENS_PER_LINE] = { }; // initialize to 0

    token[0] = strtok(buf, DELIMITER); // first token
    if (token[0]) { // zero if line is blank
        for (int n = 1; n < MAX_TOKENS_PER_LINE; n++) {
            token[n] = strtok(0, DELIMITER); // subsequent tokens
            if (!token[n])
                break; // no more tokens
        }
    }

    for (int i = 0; i < MAX_TOKENS_PER_LINE; i++) {
        singleStringParser(token[i]);
    }
}

void setLedCommands(char buf[]) {
    devideStringInSingleCommands(buf);
}

/**
 * Initialize the Socket connection and 
 * read input data in main loop
 */
int startControllerServerSocket(){   
    // init Ethernet connection
    EthernetInterface eth;
    if(strcmp(MBED_NAME,"TV") == 0){
        eth.init(LOCAL_IP_TV, NETWORK_MASK, GATEWAY);  
    }else{
        eth.init(LOCAL_IP_CEIL, NETWORK_MASK, GATEWAY);
    }
    eth.connect();
    
    tcp::Socket server;
    tcp::Socket client;
 
    Buffer buffer(SOCKET_BUFFER_SIZE);
    
    if (server.open() < 0) {
        return -1;
    }
    
    if (server.bind(ECHO_SERVER_PORT) < 0) {
        return -1;
    }
    
    if (server.listen(MAX_PENDING) < 0) {
        return -1;
    }
 
    while (server.getStatus() == network::tcp::Socket::Listening) {
        if (server.accept(client) < 0) {
            onBoardLedsOn();
            continue;
        }
        
        while (client.getStatus() == tcp::Socket::Connected) {
            buffer.flush();
            
            switch (client.read(buffer)) {
                case -1:
                    break;
                
                case 0:
                    break;
                
                default:
                    setLedCommands((char*) buffer.data());
                    continue;
            }
            
            client.shutdown();
            client.close();
        }
    }
    return 1;
}
 
/**
 * The main function.
 */
int main(){
    // one-time initialization
    i2c.frequency(I2CFREQ);
    ambientR.period_ms(1);
    ambientG.period_ms(1);
    ambientB.period_ms(1);
    
    // reset
    resetLeds();
    wait_ms(200);
    
    // run demo on startup
    //demoThread = new Thread(startDemoMode);
    //wait_ms(8500);
    //stopDemoMode();
    
    // starting main programm
    startControllerServerSocket();
}

// EOF
